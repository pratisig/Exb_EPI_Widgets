import { ImmutableObject } from 'jimu-core'

export type Period = 'epi-week' | 'month' | 'quarter' | 'year'
export type WeekMode = 'iso' | 'outbreak'
export type DateConvention = 'dmy' | 'mdy' | 'auto'
export type Statistic = 'count' | 'sum' | 'mean' | 'median' | 'min' | 'max' | 'first' | 'last' | 'distinct'

export interface SourceConfig {
  dateField?: string
  /** 'date' for a native esriFieldTypeDate field, 'text' for an EpiWeek label such as
   * `2025-W04` or `Week 03-2025`. A text field is aggregated normally but cannot be used
   * for the server-side temporal filter. */
  dateFieldType?: 'date' | 'text'
  boundaryField?: string
  valueField?: string
  valueType?: 'number' | 'date' | 'text'
  statistic: Statistic
  period: Period
  weekMode: WeekMode
  outbreakStart?: string
  dateConvention: DateConvention
  label?: string
  filterMode: 'single' | 'cumulative' | 'none'
  scaleMode?: 'dynamic' | 'fixed'
  fillMissingPeriods?: boolean
  decimalPlaces?: number
  comparisonMode?: 'continuous' | 'compare-years'
  comparisonYears?: number[]
  referenceYear?: number
}

export interface Config {
  period: Period
  weekMode: WeekMode
  dateConvention: DateConvention
  statistic: Statistic
  dateField?: string
  valueField?: string
  outbreakStart?: string
  locale: string
  accentColor?: string
  timelineColor?: string
  timelineSize?: 'small' | 'medium' | 'large'
  showDetails?: boolean
  comparisonMode?: 'continuous' | 'compare-years'
  comparisonYears?: number[]
  referenceYear?: number
  boundarySourceId?: string
  sources?: { [dataSourceId: string]: SourceConfig }
}

export type IMConfig = ImmutableObject<Config>
